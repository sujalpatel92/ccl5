<?php
session_start();
echo $_SESSION['piidON'];
echo $_SESSION['email'];
?>